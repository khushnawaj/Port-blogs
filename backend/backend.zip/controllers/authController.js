// controllers/authController.js
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const User = require('../models/User');
const ErrorResponse = require('../utils/errorResponse');
const { JWT_SECRET, JWT_EXPIRE } = require('../config/config');

const safeUser = (u) => ({
  _id: u._id,
  username: u.username,
  email: u.email,
  role: u.role,
  isVerified: u.isVerified,
  createdAt: u.createdAt,
  updatedAt: u.updatedAt
});

const signToken = (userId) => {
  return jwt.sign({ id: userId }, JWT_SECRET, { expiresIn: JWT_EXPIRE || '30d' });
};

exports.register = async (req, res, next) => {
  try {
    const { username, email, password } = req.body;
    if (!username || !email || !password) {
      return res.status(400).json({ error: 'All fields are required' });
    }

    const existing = await User.findOne({ email });
    if (existing) {
      return res.status(409).json({ error: 'Email already registered' });
    }

    const salt = await bcrypt.genSalt(10);
    const hash = await bcrypt.hash(password, salt);

    const user = await User.create({
      username,
      email,
      password: hash,
      role: 'user'
    });

    const token = signToken(user._id);
    return res.status(201).json({ token, user: safeUser(user) });
  } catch (err) {
    next(err);
  }
};

exports.login = async (req, res, next) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) {
      return res.status(400).json({ error: 'Please provide email and password' });
    }

    const user = await User.findOne({ email: email.trim().toLowerCase() }).select('+password');
    if (!user) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    const match = await bcrypt.compare(password, user.password);
    if (!match) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    const token = signToken(user._id);
    return res.status(200).json({
      token,
      user: safeUser(user)
    });
  } catch (err) {
    console.error('Login error:', err);
    next(err);
  }
};


exports.getMe = async (req, res, next) => {
  try {
    const user = await User.findById(req.user.id || req.user._id);
    if (!user) return res.status(404).json({ error: 'User not found' });
    return res.json(safeUser(user));
  } catch (err) {
    next(err);
  }
};

// Minimal placeholders to avoid 404s if frontend calls these routes
exports.forgotPassword = async (req, res, next) => {
  return res.json({ message: 'If this email exists, a reset link has been sent.' });
};
exports.resetPassword = async (req, res, next) => {
  return res.json({ message: 'Reset password endpoint placeholder' });
};
exports.verifyEmail = async (req, res, next) => {
  return res.json({ message: 'Verify email endpoint placeholder' });
};
exports.resendVerificationEmail = async (req, res, next) => {
  return res.json({ message: 'Resend verification endpoint placeholder' });
};
