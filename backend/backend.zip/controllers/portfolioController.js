const Home = require("../models/Home");
const About = require("../models/About");
const Resume = require("../models/Resume"); // used for education + experience
const Project = require("../models/Project");
const Contact = require("../models/Contact");

// ========================
// Get Full Portfolio
// ========================
exports.getPortfolio = async (req, res) => {
  try {
    const userId = req.params.userId;

    const home = await Home.findOne({ userId });
    const about = await About.findOne({ userId });
    const resume = await Resume.find({ userId }); // education + experience
    const projects = await Project.find({ userId });
    const contact = await Contact.findOne({ userId });

    res.json({
      success: true,
      portfolio: {
        home,
        about,
        resume,
        projects,
        contact,
      },
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

// ========================
// Save or Update Full Portfolio
// ========================
exports.upsertProfile = async (req, res) => {
  try {
    const userId = req.user.id;
    const { home, about, resume, projects, contact } = req.body;

    if (home) {
      await Home.findOneAndUpdate({ userId }, { ...home, userId }, { upsert: true, new: true });
    }

    if (about) {
      await About.findOneAndUpdate({ userId }, { ...about, userId }, { upsert: true, new: true });
    }

    if (resume && resume.length > 0) {
      await Resume.deleteMany({ userId });
      await Resume.insertMany(resume.map(r => ({ ...r, userId })));
    }

    if (projects && projects.length > 0) {
      await Project.deleteMany({ userId });
      await Project.insertMany(projects.map(p => ({ ...p, userId })));
    }

    if (contact) {
      await Contact.findOneAndUpdate({ userId }, { ...contact, userId }, { upsert: true, new: true });
    }

    res.json({ success: true, message: "Portfolio saved/updated successfully" });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

// ========================
// Education (Resume collection)
// ========================
exports.getEducation = async (req, res) => {
  try {
    const education = await Resume.find({ type: "education" });
    res.json({ success: true, education });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

exports.getEducationById = async (req, res) => {
  try {
    const education = await Resume.findById(req.params.id);
    if (!education) return res.status(404).json({ success: false, message: "Education not found" });
    res.json({ success: true, education });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

exports.addEducation = async (req, res) => {
  try {
    const userId = req.user.id;
    const newEducation = new Resume({ ...req.body, type: "education", userId });
    const savedEducation = await newEducation.save();
    res.json({ success: true, education: savedEducation });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

exports.updateEducation = async (req, res) => {
  try {
    const updatedEducation = await Resume.findByIdAndUpdate(req.params.id, req.body, { new: true });
    res.json({ success: true, education: updatedEducation });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

exports.deleteEducation = async (req, res) => {
  try {
    await Resume.findByIdAndDelete(req.params.id);
    res.json({ success: true, message: "Education deleted" });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

// ========================
// Experience (Resume collection)
// ========================
exports.getExperience = async (req, res) => {
  try {
    const experience = await Resume.find({ type: "experience" });
    res.json({ success: true, experience });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

exports.getExperienceById = async (req, res) => {
  try {
    const experience = await Resume.findById(req.params.id);
    if (!experience) return res.status(404).json({ success: false, message: "Experience not found" });
    res.json({ success: true, experience });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

exports.addExperience = async (req, res) => {
  try {
    const userId = req.user.id;
    const newExperience = new Resume({ ...req.body, type: "experience", userId });
    const savedExperience = await newExperience.save();
    res.json({ success: true, experience: savedExperience });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

exports.updateExperience = async (req, res) => {
  try {
    const updatedExperience = await Resume.findByIdAndUpdate(req.params.id, req.body, { new: true });
    res.json({ success: true, experience: updatedExperience });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

exports.deleteExperience = async (req, res) => {
  try {
    await Resume.findByIdAndDelete(req.params.id);
    res.json({ success: true, message: "Experience deleted" });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

// ========================
// Projects
// ========================
exports.getProjects = async (req, res) => {
  try {
    const projects = await Project.find();
    res.json({ success: true, projects });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

exports.getProjectById = async (req, res) => {
  try {
    const project = await Project.findById(req.params.id);
    if (!project) return res.status(404).json({ success: false, message: "Project not found" });
    res.json({ success: true, project });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

exports.addProject = async (req, res) => {
  try {
    const userId = req.user.id;
    const newProject = new Project({ ...req.body, userId });
    const savedProject = await newProject.save();
    res.json({ success: true, project: savedProject });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

exports.updateProject = async (req, res) => {
  try {
    const updatedProject = await Project.findByIdAndUpdate(req.params.id, req.body, { new: true });
    res.json({ success: true, project: updatedProject });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

exports.deleteProject = async (req, res) => {
  try {
    await Project.findByIdAndDelete(req.params.id);
    res.json({ success: true, message: "Project deleted" });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

// ========================
// Contact
// ========================
exports.getContact = async (req, res) => {
  try {
    const contact = await Contact.find();
    res.json({ success: true, contact });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

exports.updateContact = async (req, res) => {
  try {
    const userId = req.user.id;
    const updatedContact = await Contact.findOneAndUpdate({ userId }, { ...req.body, userId }, { new: true, upsert: true });
    res.json({ success: true, contact: updatedContact });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

// ========================
// Clone Portfolio (placeholder)
// ========================
exports.clonePortfolio = async (req, res) => {
  try {
    res.json({ success: true, message: "Clone portfolio feature coming soon" });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};
