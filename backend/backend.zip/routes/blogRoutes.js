const express = require('express');
const {
  getBlogPosts,
  getBlogPost,
  createBlogPost,
  updateBlogPost,
  deleteBlogPost,
  uploadBlogImage,
  searchBlogPosts,
  approveBlogPost
} = require('../controllers/blogController');
const { protect, authorize } = require('../middleware/auth');
const upload = require('../middleware/upload');

const router = express.Router();

// Search should be before :id to avoid conflicts
router.get('/search', searchBlogPosts);

// Public routes
router.get('/', getBlogPosts);
router.get('/:id', getBlogPost);

// Protected routes
router.post('/', protect, createBlogPost);
router.put('/:id', protect, updateBlogPost);
router.delete('/:id', protect, deleteBlogPost);

// Upload image
router.put('/:id/image', protect, upload, uploadBlogImage);

// Approve blog post (admin only)
router.put('/:id/approve', protect, authorize('admin'), approveBlogPost);

module.exports = router;
