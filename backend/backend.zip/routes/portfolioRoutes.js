const express = require("express");
const {
  getPortfolio,
  upsertProfile,
  clonePortfolio,

  // Education
  getEducation,
  getEducationById,
  addEducation,
  updateEducation,
  deleteEducation,

  // Experience
  getExperience,
  getExperienceById,
  addExperience,
  updateExperience,
  deleteExperience,

  // Projects
  getProjects,
  getProjectById,
  addProject,
  updateProject,
  deleteProject,

  // Contact
  getContact,
  updateContact,
} = require("../controllers/portfolioController");

const { protect } = require("../middleware/auth");

const router = express.Router();

// ✅ Get full portfolio
router.route("/:userId").get(getPortfolio);

// ✅ Save or update portfolio
router.post("/post", protect, upsertProfile);

// ✅ Clone portfolio
router.post("/:userId/clone", protect, clonePortfolio);

// =================== Education ===================
router.route("/education")
  .get(getEducation)
  .post(protect, addEducation);

router.route("/education/:id")
  .get(getEducationById)
  .put(protect, updateEducation)
  .delete(protect, deleteEducation);

// =================== Experience ===================
router.route("/experience")
  .get(getExperience)
  .post(protect, addExperience);

router.route("/experience/:id")
  .get(getExperienceById)
  .put(protect, updateExperience)
  .delete(protect, deleteExperience);

// =================== Projects ===================
router.route("/projects")
  .get(getProjects)
  .post(protect, addProject);

router.route("/projects/:id")
  .get(getProjectById)
  .put(protect, updateProject)
  .delete(protect, deleteProject);

// =================== Contact ===================
router.route("/contact")
  .get(getContact)
  .put(protect, updateContact);

module.exports = router;
