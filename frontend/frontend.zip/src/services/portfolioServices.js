import api from "./api";

// Get full portfolio by userId
export const getPortfolio = async (userId) => {
  const res = await api.get(`/portfolio/${userId}`);
  return res.data;
};

// Save or update portfolio
export const upsertPortfolio = async (portfolioData) => {
  const res = await api.post("/portfolio/post", portfolioData);
  return res.data;
};

// Education APIs
export const getEducation = async () => {
  const res = await api.get("/portfolio/education");
  return res.data;
};

export const getEducationById = async (id) => {
  const res = await api.get(`/portfolio/education/${id}`);
  return res.data;
};

export const addEducation = async (eduData) => {
  const res = await api.post("/portfolio/education", eduData);
  return res.data;
};

export const updateEducation = async (id, eduData) => {
  const res = await api.put(`/portfolio/education/${id}`, eduData);
  return res.data;
};

export const deleteEducation = async (id) => {
  const res = await api.delete(`/portfolio/education/${id}`);
  return res.data;
};


