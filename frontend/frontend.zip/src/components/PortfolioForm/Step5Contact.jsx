import React from "react";
import './Step5Contact.scss';

const Step5Contact = ({ data, handleChange }) => {
  return (
    <div className="step5-contact">
      <h2>Step 5: Contact</h2>
      <input
        type="email"
        placeholder="Email"
        value={data.email}
        onChange={(e) => handleChange("contact", "email", e.target.value)}
      />
      <input
        type="text"
        placeholder="Phone"
        value={data.phone}
        onChange={(e) => handleChange("contact", "phone", e.target.value)}
      />
      <input
        type="text"
        placeholder="LinkedIn"
        value={data.linkedin}
        onChange={(e) => handleChange("contact", "linkedin", e.target.value)}
      />
      <div className="btn-group">
        {/* <button className="btn" onClick={prevStep}>Back</button> */}
        {/* <button className="btn submit" onClick={handleSubmit}>Submit</button> */}
      </div>
    </div>
  );
};

export default Step5Contact;
