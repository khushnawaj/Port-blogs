import React from "react";
import './Step1Home.scss';

const Step1Home = ({ data, handleChange, }) => {
  return (
    <div className="step1-home">
      <h2>Step 1: Home</h2>
      <input
        type="text"
        placeholder="Full Name"
        value={data.fullName}
        onChange={(e) => handleChange("home", "fullName", e.target.value)}
      />
      <input
        type="text"
        placeholder="Tagline"
        value={data.tagline}
        onChange={(e) => handleChange("home", "tagline", e.target.value)}
      />
      <input
        type="text"
        placeholder="Profile Image URL"
        value={data.profileImage}
        onChange={(e) => handleChange("home", "profileImage", e.target.value)}
      />
      {/* <button className="btn-next" onClick={nextStep}>Next</button> */}
    </div>
  );
};

export default Step1Home;
