import React from "react";
import './Step4Projects.scss';

const Step4Projects = ({ data, handleChange }) => {
  return (
    <div className="step4-projects">
      <h2>Step 4: Projects</h2>
      <input
        type="text"
        placeholder="Project Title"
        value={data[0].title}
        onChange={(e) => handleChange("projects", "title", e.target.value)}
      />
      <input
        type="text"
        placeholder="Project Description"
        value={data[0].description}
        onChange={(e) => handleChange("projects", "description", e.target.value)}
      />
      <input
        type="text"
        placeholder="Project Link"
        value={data[0].link}
        onChange={(e) => handleChange("projects", "link", e.target.value)}
      />
      {/* <div className="btn-group">
        <button className="btn" onClick={prevStep}>Back</button>
        <button className="btn" onClick={nextStep}>Next</button>
      </div> */}
    </div>
  );
};

export default Step4Projects;
