import React from "react";
import './Step3Resume.scss';

const Step3Resume = ({ data, handleChange }) => {
  return (
    <div className="step3-resume">
      <h2>Step 3: Resume</h2>
      <input
        type="text"
        placeholder="Education"
        value={data.education}
        onChange={(e) => handleChange("resume", "education", [e.target.value])}
      />
      <input
        type="text"
        placeholder="Experience"
        value={data.experience}
        onChange={(e) => handleChange("resume", "experience", [e.target.value])}
      />
      {/* <div className="btn-group">
        <button className="btn" onClick={prevStep}>Back</button>
        <button className="btn" onClick={nextStep}>Next</button>
      </div> */}
    </div>
  );
};

export default Step3Resume;
